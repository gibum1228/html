function doSomething(a) {
    return a.reverse()
}

let a = [
    [1, 2],
    [3, 4, 5],
    [6, 7, 8, 9]
];

doSomething(a);

console.log(a);
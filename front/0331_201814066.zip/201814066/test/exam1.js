function space1(s) {
    return s.indexOf(" ")
}

console.log(space1("a b c"));
console.log(space1("one two three"));
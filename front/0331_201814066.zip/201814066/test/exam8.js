function call8(f) {
    console.log(f(8))
}

function add(i) {
    return i + 100;
}

call8(add);